package com.example.tecnisis.ui.casosDeUso.evaluadorArtistico.detalleSolicitud

class DetalleSolicitudUiState {

}