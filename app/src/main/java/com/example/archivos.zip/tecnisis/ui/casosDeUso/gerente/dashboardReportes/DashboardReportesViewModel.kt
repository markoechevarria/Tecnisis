package com.example.tecnisis.ui.casosDeUso.gerente.dashboardReportes

class DashboardReportesViewModel {
}