package com.example.tecnisis.ui.casosDeUso.anfitrion.listarExpertosDisponibles

data class ListarExpertosDisponiblesUiState (
    val expertoSeleccionado: Int = -1,
    val habilitadoBoton: Boolean = false
)