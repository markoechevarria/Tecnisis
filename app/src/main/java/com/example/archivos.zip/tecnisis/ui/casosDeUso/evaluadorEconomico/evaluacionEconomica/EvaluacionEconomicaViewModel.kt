package com.example.tecnisis.ui.casosDeUso.evaluadorEconomico.evaluacionEconomica

class EvaluacionEconomicaViewModel {
}