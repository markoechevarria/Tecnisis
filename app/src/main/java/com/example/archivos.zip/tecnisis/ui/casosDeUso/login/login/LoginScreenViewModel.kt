package com.example.tecnisis.ui.casosDeUso.login.login

class LoginScreenViewModel {
}