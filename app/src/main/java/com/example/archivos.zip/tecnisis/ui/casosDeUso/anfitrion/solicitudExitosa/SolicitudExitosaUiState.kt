package com.example.tecnisis.ui.casosDeUso.anfitrion.solicitudExitosa

class SolicitudExitosaUiState {
}