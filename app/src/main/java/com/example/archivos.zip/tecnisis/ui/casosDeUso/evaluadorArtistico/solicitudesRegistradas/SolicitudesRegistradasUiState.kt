package com.example.tecnisis.ui.casosDeUso.evaluadorArtistico.solicitudesRegistradas

class SolicitudesRegistradasUiState {
}