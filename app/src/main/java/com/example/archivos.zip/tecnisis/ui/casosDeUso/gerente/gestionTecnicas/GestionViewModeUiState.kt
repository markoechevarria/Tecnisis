package com.example.tecnisis.ui.casosDeUso.gerente.gestionTecnicas

class GestionViewModeUiState {
}