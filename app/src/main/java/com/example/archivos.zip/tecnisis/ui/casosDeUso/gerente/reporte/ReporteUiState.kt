package com.example.tecnisis.ui.casosDeUso.gerente.reporte

class ReporteUiState {
}