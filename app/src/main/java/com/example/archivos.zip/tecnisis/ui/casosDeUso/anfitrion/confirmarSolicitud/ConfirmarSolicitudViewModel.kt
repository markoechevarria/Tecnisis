package com.example.tecnisis.ui.casosDeUso.anfitrion.confirmarSolicitud

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ConfirmarSolicitudViewModel : ViewModel() {
    // private val _uiState = MutableStateFlow(ConfirmarSolicitudUiState() )
    // val uiState: StateFlow<ConfirmarSolicitudUiState> = _uiState.asStateFlow()
}