package com.example.tecnisis.ui.casosDeUso.gerente.nuevaTecnica

class NuevaTecnicaUiState {
}