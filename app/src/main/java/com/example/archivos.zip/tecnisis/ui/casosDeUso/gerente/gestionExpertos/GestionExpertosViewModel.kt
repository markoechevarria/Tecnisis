package com.example.tecnisis.ui.casosDeUso.gerente.gestionExpertos

class GestionExpertosViewModel {
}