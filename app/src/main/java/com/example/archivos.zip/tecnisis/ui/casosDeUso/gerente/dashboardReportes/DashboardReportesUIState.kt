package com.example.tecnisis.ui.casosDeUso.gerente.dashboardReportes

class DashboardReportesUIState {
}


data class ListarExpertosDisponiblesUiState (
    val expertoSeleccionado: Int = -1,
    val habilitadoBoton: Boolean = false
)